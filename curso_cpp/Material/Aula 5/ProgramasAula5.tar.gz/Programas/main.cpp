#include<iostream>
#include<string>

#include"Pessoa.hpp"


int main(){
	Pessoa p1{"Joao", 20};
	Pessoa p2{"Maria"};
	Pessoa p3{"Jonas", 21, 11111111111};//1 x11 é um cpf valido de acordo com meu algoritmo

	std::cout << "P1: " << p1.getNome() << " " << p1.getIdade() << std::endl;
	std::cout << "P2: " << p2.getNome() << " " << p2.getIdade() << std::endl;
	std::cout << "P3: " << p3.getNome() << " " << p3.getIdade() << " " << p3.getCpf() << std::endl;

	return 0;
}
