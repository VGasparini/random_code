#ifndef PESSOA_H
#define PESSOA_H

#include<string>

class Pessoa{
	public:
		inline unsigned char getIdade(){
			return idade;
		}
		inline void setIdade(const unsigned char novaIdade){
			idade = novaIdade;
		}
		/*unsigned char getIdade();
		void setIdade(unsigned char novaIdade);*/

		std::string getNome();
		void setNome(std::string novoNome);

		unsigned long getCpf();
		bool setCpf(unsigned long novoCpf);
	private:
		bool validarCPF(unsigned long cpfTeste);

		std::string nome;
		unsigned long cpf;
		unsigned char idade;
};

#endif
