#include<iostream>
#include"Pessoa.hpp"


int main(){
	Pessoa p1;
	std::cin >> p1.nome;
	std::cout << p1.nome << std::endl;


	return 0;
}
