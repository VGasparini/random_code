#include<iostream>
#include<string>

#include"Pessoa.hpp"


int main(){
	Pessoa p1;
	p1.setNome("Joao da Silva");
	p1.setIdade(22);
	if(!p1.setCpf(1231293)){
		std::cout << "CPF invalido, nada alterado"<< std::endl; 
	}
	if(!p1.setCpf(11111111111)){
		std::cout << "CPF invalido, nada alterado"<< std::endl;
	}	
	std::cout << "Dados da pessoa: " << p1.getNome() << "\t" << (unsigned short int) p1.getIdade() << "\t" << p1.getCpf() << std::endl;

	return 0;
}
