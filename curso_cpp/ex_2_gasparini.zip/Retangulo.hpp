#ifndef RETANGULO_H
#define RETANGULO_H

#include <math.h>
#include "Ponto.hpp"

class Retangulo
{
public:
    Ponto p1;
    Ponto p2;
    Retangulo(Ponto p1_ = Ponto(), Ponto p2_ = Ponto(1, 1))
    {
        p1 = p1_;
        p2 = p2_;
    };
    Retangulo(Ponto p1_, int largura, int altura)
    {
        p1 = p1_;
        p2 = Ponto(p1.x + largura, p1.y + altura);
    };
    Retangulo(Ponto p1_, int lado, double diagonal)
    {
        p1 = p1_;
        p2 = Ponto(p1.x + lado, p1.y + sqrt(diagonal * diagonal - lado * lado));
    };
    double area(void);
    double diagonal(void);
};

#endif