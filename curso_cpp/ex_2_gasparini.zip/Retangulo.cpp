#include "Retangulo.hpp"

double Retangulo::area(void)
{
    double seg_x = p1.x > p2.x ? p1.x - p2.x : p2.x - p1.x;
    double seg_y = p1.y > p2.y ? p1.y - p2.y : p2.y - p1.y;
    return seg_x * seg_y;
}

double Retangulo::diagonal(void)
{
    return p1.segmento(p2);
}
