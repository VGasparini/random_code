/* Curso C++
 * Vinicius Gasparini
 * Exericio 3
*/

#include <iostream>
#include <string>

#include "Ponto.hpp"
#include "Retangulo.hpp"

int main()
{
    std::string nome;
    std::cout << "Qual teu nome?\n->";
    std::getline(std::cin,nome);
    bool premio = nome.find('v') != std::string::npos;

    char op;
    std::cout << "Determine o modo de construção do retangulo\n1- Dois pontos diagonais\n2- Um ponto, largura e altura\n3- Um ponto, largura e tamanho da diagonal\n0- Retangulo 1x1\n->";
    std::cin >> op;

    double x, y;
    Retangulo ret;
    Ponto p1, p2;
    switch (op)
    {
    case '0':
        ret = Retangulo();
        std::cout << "Diagonal = " << ret.diagonal() << std::endl;
        break;
    case '1':
        std::cout << "Digite as coordenadas de P1(x,y)\n->";
        std::cin >> x >> y;
        p1 = Ponto(x, y);
        std::cout << "Digite as coordenadas de P2(x,y)\n->";
        std::cin >> x >> y;
        p2 = Ponto(x, y);
        ret = Retangulo(p1, p2);
        std::cout << "Diagonal = " << ret.diagonal() << std::endl;
        break;
    case '2':
        int largura, altura;
        std::cout << "Digite as coordenadas de P1(x,y)\n->";
        std::cin >> x >> y;
        p1 = Ponto(x, y);
        std::cout << "Digite a largura\n->";
        std::cin >> largura;
        std::cout << "Digite a altura\n->";
        std::cin >> altura;
        ret = Retangulo(p1, largura, altura);
        std::cout << "Coordenadas do P2(" << ret.getP2().x << "," << ret.getP2().y << ")" << std::endl;
        std::cout << "Diagonal = " << ret.diagonal() << std::endl;
        break;
    case '3':
        int lado;
        double diagonal;
        std::cout << "Digite as coordenadas de P1(x,y)\n->";
        std::cin >> x >> y;
        p1 = Ponto(x, y);
        std::cout << "Digite o tamanho de um lado\n->";
        std::cin >> lado;
        std::cout << "Digite o tamanho da diagonal\n->";
        std::cin >> diagonal;
        ret = Retangulo(p1, lado, diagonal);
        std::cout << "Coordenadas do P2(" << ret.getP2().x << "," << ret.getP2().y << ")" << std::endl;
        std::cout << "Tamanho do lado = " << abs(ret.getP1().y - ret.getP2().y) << std::endl;
        break;
    default:
        std::cout << "Saindo";
        break;
    }
    std::cout << "Area = " << ret.area() << std::endl;
    std::cout << "Perimetro = " << ret.perimetro() << std::endl;
    
    std::cout << std::endl << ( premio ? "Parabéns, você ganhou um prêmio. Reivindique com o Gaspa" : "Mais sorte na próxima :(" ) << std::endl;
    std::cout << "Ah " + nome + " não esquece de lavar as mãos hein!" << std::endl;
}

/*
 *Exemplo de 2 pontos ---------------> p1(1,1), p2[6,13]
 *Exemplo de ponto, lado, lado: -----> p1(1,1), 5, 12
 *Exemplo de ponto, lado, diagonal: -> p1(1,1), 5, 13
*/