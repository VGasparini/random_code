#include "Retangulo.hpp"

double Retangulo::area(void)
{
    double seg_x = _p1.x > _p2.x ? _p1.x - _p2.x : _p2.x - _p1.x;
    double seg_y = _p1.y > _p2.y ? _p1.y - _p2.y : _p2.y - _p1.y;
    return seg_x * seg_y;
}

double Retangulo::perimetro(void)
{
    double seg_x = _p1.x > _p2.x ? _p1.x - _p2.x : _p2.x - _p1.x;
    double seg_y = _p1.y > _p2.y ? _p1.y - _p2.y : _p2.y - _p1.y;
    return 2*seg_x + 2*seg_y;
}

double Retangulo::diagonal(void)
{
    return _p1.segmento(_p2);
}

Ponto Retangulo::getP1(void){
    return _p1;
}

Ponto Retangulo::getP2(void){
    return _p2;
}