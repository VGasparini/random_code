#include <math.h>
#include "Ponto.hpp"

double Ponto::segmento(Ponto p2)
{
    double seg_x = x - p2.x;
    double seg_y = y - p2.y;
    return sqrt(seg_x * seg_x + seg_y * seg_y);
}