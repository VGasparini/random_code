#ifndef PONTO_H
#define PONTO_H

class Ponto
{
public:
    double x;
    double y;
    Ponto(double x_ = 0, double y_ = 0)
    {
        x = x_;
        y = y_;
    };
    double segmento(Ponto p2);
};

#endif