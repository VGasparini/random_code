#ifndef RETANGULO_H
#define RETANGULO_H

#include <math.h>
#include "Ponto.hpp"

class Retangulo
{
private:
    Ponto _p1;
    Ponto _p2;
public:
    Retangulo(Ponto p1 = Ponto(), Ponto p2 = Ponto(1, 1))
    {
        _p1 = p1;
        _p2 = p2;
    };
    Retangulo(Ponto p1, int largura, int altura)
    {
        _p1 = p1;
        _p2 = Ponto(_p1.x + largura, _p1.y + altura);
    };
    Retangulo(Ponto p1, int lado, double diagonal)
    {
        _p1 = p1;
        _p2 = Ponto(_p1.x + lado, _p1.y + sqrt(diagonal * diagonal - lado * lado));
    };
    double area(void);
    double perimetro(void);
    double diagonal(void);
    Ponto getP1(void);
    Ponto getP2(void);
};

#endif