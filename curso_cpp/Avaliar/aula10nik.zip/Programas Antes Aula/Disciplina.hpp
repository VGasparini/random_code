#ifndef DISCIPLINA_H
#define DISCIPLINA_H

#include <string>
#include <list>

#include "Pessoa.hpp"

class Disciplina{
	public:
		Disciplina(std::string nome);

		std::string getNome();
		void setNome(std::string nome);
		
		int getCargaHoraria();
		void setCargaHoraria(unsigned int cargaHoraria);
		
		Pessoa* getProfessor();
		void setProfessor(Pessoa* professor);

		void imprimeDados(std::string& cabecalho, unsigned int& cargaTotalCurso);

		void adicionarAluno(Pessoa* aluno);

		std::list<Pessoa*> getListaAlunos();
	
		void removerAluno(Pessoa* aluno);
		void removerAluno(unsigned long cpf);
	private:
		std::string nome;
		unsigned short int cargaHoraria;
		std::list<Pessoa*> listaAlunos;
		Pessoa* professor;
};
#endif
