#include <iostream>
#include <list>

#include "Pessoa.hpp"
#include "Disciplina.hpp"

int main(){
	Disciplina d{"a"};

	Pessoa* p{new Pessoa{"a"}};

	d.adicionarAluno(new Pessoa{"d"});
	d.adicionarAluno(new Pessoa{"b"});
	d.adicionarAluno(new Pessoa{"c"});
	d.adicionarAluno(p);

	std::list<Pessoa*> lista = d.getListaAlunos();//problemas com a utilização direta do d.getListaAlunos() por isso criei uma nova variável
	std::list<Pessoa*>::iterator it;

	for(it = lista.begin();it != lista.end();it++){
		std::cout << (*it)->getNome() << std::endl;
	}
	
	d.removerAluno(p);

	std::cout<<std::endl;

	for(it = lista.begin();it != lista.end();it++){
		std::cout << (*it)->getNome() << std::endl;
	}

	for(it = lista.begin();it != lista.end();it++){
		delete *it;
	}

	lista.clear();
	d.getListaAlunos().clear();

	return 0;
}
