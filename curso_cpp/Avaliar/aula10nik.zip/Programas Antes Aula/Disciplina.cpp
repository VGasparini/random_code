#include "Disciplina.hpp"

#include<iostream>

Disciplina::Disciplina(std::string nome)
	:nome{nome} {
}

std::string Disciplina::getNome(){
	return this->nome;
}

void Disciplina::setNome(std::string nome){
	this->nome = nome;
}

int Disciplina::getCargaHoraria(){
	return this->cargaHoraria;
}

void Disciplina::setCargaHoraria(unsigned int cargaHoraria){
	this->cargaHoraria = cargaHoraria;
}

Pessoa* Disciplina::getProfessor(){
	return this->professor;
}

void Disciplina::setProfessor(Pessoa* professor){
	this->professor = professor;
}

void Disciplina::imprimeDados(std::string& cabecalho, unsigned int& cargaTotalCurso){
	double pctCurso = (double)cargaHoraria/cargaTotalCurso;
	pctCurso = pctCurso * 100;
	std::cout << cabecalho << std::endl;
	std::cout << "Disciplina: " << this->nome << std::endl;
	std::cout << "Carga: " << this->cargaHoraria << std::endl;
	std::cout << "Percentagem do curso: " << pctCurso << "%" << std::endl;
	std::cout << "Professor: " << this->professor->getNome() << std::endl;

}

std::list<Pessoa*> Disciplina::getListaAlunos(){
	return this->listaAlunos;
}

void Disciplina::adicionarAluno(Pessoa* aluno){
	this->listaAlunos.push_back(aluno);
}

void Disciplina::removerAluno(Pessoa* aluno){
	std::list<Pessoa*>::iterator it = this->listaAlunos.begin();
	//std::cout<< "Remover aluno: "+(*this->listaAlunos.end())->getNome()<<std::endl;
	while(it != this->listaAlunos.end()){
		if(*it == aluno){
			delete *it;
			it = this->listaAlunos.erase(it);//continuar a percorrer para garantir que não haja duplicatas
		}else{
			it++;
		}
	}
}

void Disciplina::removerAluno(unsigned long cpf){
	std::list<Pessoa*>::iterator it = this->listaAlunos.begin();
	while(it != this->listaAlunos.end()){
		if((*it)->getCpf()==cpf){
			delete *it;
			it = this->listaAlunos.erase(it);
		}else{
			it++;
		}
	}
}
